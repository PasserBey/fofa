import requests
import argparse
import base64
import os
import re
import time
import sys
import json
import codecs


#proxies = {"http": "http://127.0.0.1:8080", "https": "http://127.0.0.1:8080"}
def banner():
    print(
"""
         _____      __       ____        _     _           
        |  ___|__  / _| __ _/ ___| _ __ (_) __| | ___ _ __ 
        | |_ / _ \| |_ / _` \___ \| '_ \| |/ _` |/ _ \ '__|
        |  _| (_) |  _| (_| |___) | |_) | | (_| |  __/ |   
        |_|  \___/|_|  \__,_|____/| .__/|_|\__,_|\___|_|
                                  |_|                                                
                          coded by Passerby
"""
         )
   
    print("\n")
    print('           fofa采集工具使用方法')
    print("\n")
    print('           fofa高级查询请输入相关eamil和key')
    print("\n")
    print('           python3 bgbingfofa.py -e/--email email -k/--key key -s/--size 100/1000/10000')
    print("\n")
    print('           python3 bgbingfofa.py -h/--help')
"""
    print("\n")
if len(sys.argv)==1:
    banner()
    sys.exit()
"""

parser = argparse.ArgumentParser(description='bgbingfofaapi help')
parser.add_argument('-e','--email', help='Please Input your email!',default='*******************')   #此处需填入开通会员的fofa邮箱
parser.add_argument('-k','--key', help='Please Input your key!',default='*********************')  #此处填入用户资料里面的 key 值
parser.add_argument('-s','--size', help='Please Input you want get size!',default='10000')
parser.add_argument('-f','--fields', help='Please Input fields yon want look! eg:host,ip,port,country,province,city..',default='')
args=parser.parse_args()
email=args.email
key=args.key
size=args.size
fields=args.fields

#根据去除用户输入国家代码下所有的province
def get_province(sentence1):
    file_dir = "./area/"                    #指定读取的province路径(包含目前fofa收录的所有国家)
    
    L = []                                  #定义一个空list列表存放./area 路径下的文件。 
    
    lis = []                                # 定义一个 list列表存放输入的排除国家。
   #将用户输入的国家二位代码放入list中
    for i in range(175):
        country = str(input('你想过滤掉的第%i个国家代码是(键入S并回车停止输出)：'%(i+1))).upper()
        if country.upper() == 'S':
            break
        lis.append(country)                 #列表追加
    print("fofa语句为:" +sentence1)
    print("过滤掉的国家代码是:")
    print (lis)
    #获取排除国家以为的其他国的所有province(依据字典生成，存在部分地区编码缺陷问题)
    if lis is not None:
        for root, dirs, files in os.walk(file_dir, topdown=False):
            for file in files:  
                #print(file)        # 当前路径下所有非目录子文件
                #file=file.split()
                fileName,extensionName = os.path.splitext(file)
                if extensionName =='.txt':
                    L.append(fileName)          #读取./area 路径下面的所有文件格式为.txt的文件并将前缀放入L中
            for i in lis:      
                try:
                    L.remove(i)                 #将用户输入的国家编码从整体的list中去除
                except:
                    print ("Error: 请确认输入的国家代码是否正确") 
                    break
            data = []                           #定义空的list用于读取各个国家的province
            #读取去除排除国家以外的其余国家的province 放至整体的 list 中
            for path in L:
                p_name = file_dir + path + ".txt"
                with open(p_name, encoding='gb18030', errors='ignore') as f:
                    temp = f.read().replace(" ", "")  #读取指定以为国家的province 
                    temp = temp.split()
                    #print(type(temp))
                    data += temp  #  将所有省份list 合并 
                    #print(data)
            return (data) 

#身份校验是否为高级用户(*****本脚本只支持高级语法******)
def check_ident():
    url="https://fofa.so/api/v1/info/my?email="+email+"&key="+key
    header={
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36",
        "Content-Type":"application/x-www-form-urlencoded"
            }
    response=requests.get(url,headers=header)
    if 'errmsg' not in response.text:
        print("恭喜~登入凭证OK")
        print("\n")
        while 1:
            sentence=input("请输入fofa语句 >>>")
            sentence=base64.b64encode(sentence.encode('utf-8')).decode("utf-8")
            url="https://fofa.so/api/v1/search/all?email="+email+"&key="+key+"&qbase64="+sentence+"&fields="+fields+"&size="+size
            response=requests.get(url,headers=header)
            time.sleep(3)
            if 'errmsg' not in response.text:
                #创建存放结果的文本 有的话删除没有则自动
                path ="./result/"+"result.txt"
                if os.path.exists(path):
                    os.remove(path)
                r1 = json.loads(response.text)
                num = len(r1['results'])          
                #当查询结果小于10000时直接，打印全部
                if num < 10000:
                    for i in r1['results']:   #遍历结果中的key 为 results的 value值
                        s=i[0]                 #获取fofa返回结果中的内容 IP+port 格式
                        f = codecs.open(path,'a','utf-8')
                        #f.write(str(i)+"\n")
                        f.write(s+"\n")
                    f.close()
                    print("结果读取成功~共%d条记录"%num)
                #当查询条目大于10000需进一步校验。
                else:
                    print("本次查询结果超出10000条，请精确查找条件")
                    print("+++++++++++++++++++++++++++")
                    sentence1 = input("请输入fofa语句 >>>")
                    province = get_province(sentence1)
                    #print(province)
                    #path ="./result/" 
                    #os.makedirs(path,exist_ok=True)
                    #遍历所有省份 作为拼接条件 并结合fofa语句进行查询
                    for pro in province:                       
                        sentence = sentence1 +"&&" + "province=" + pro
                        sentence=base64.b64encode(sentence.encode('utf-8')).decode("utf-8")
                        #print(sentence)
                        url="https://fofa.so/api/v1/search/all?email="+email+"&key="+key+"&qbase64="+sentence+"&fields="+fields+"&size="+size
                        response=requests.get(url,headers=header)
                        #print(response.text)
                        time.sleep(3)
                        if 'errmsg' not in response.text:                          
                            #path1 = path + "result.txt"
                            r1 = json.loads(response.text)                          
                            for i in r1['results']:   #遍历结果中的key 为 results的 value值
                                if i is not None:
                                    s=i[0]
                                    f = codecs.open(path,'a','utf-8')
                                    #f.write(str(i)+"\n")
                                    f.write(s+"\n")
                                else:
                                    print("省份不存在")
                                    continue
                        else:
                            print("fofa语句是:"+sentence)
                            print("fofa语句不正确或以区域编码查询无法正常显示")                      
            else:
                print("fofa语句不正确")
    else:
        print("email或key不正确")

if __name__ == '__main__':
    banner()
    check_ident()